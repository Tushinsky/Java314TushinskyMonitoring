import in.Front;

public class Main {
    public static void main(String[] args) {
        Front front = new Front();
        front.start();
    }
}
